




<script src="{{ url('public/bms/dist/js/bootstrap.min.js')}}"></script>

<script src="{{ url('public/frontend/js/jquery-ui.js') }}"></script>
<script src="{{ url('public/frontend/js/plugins.min.js') }}"></script>
<script src="{{ url('public/frontend/js/bootstrap-datepicker.js') }}"></script>
<script src="{{ url('public/frontend/js/custom.js') }}"></script>

<!-- Javascript -->

 <!-- This page JS -->
<script src="{{url('public/bms/assets/js/js-index.js')}}"></script>

 <!-- Custom functions -->
 <script src="{{url('public/bms/assets/js/functions.js')}}"></script>

 <!-- Picker UI-->
<script src="{{url('public/bms/assets/js/jquery-ui.js')}}"></script>

<!-- Easing -->

 <script src="{{url('public/bms/assets/js/jquery.easing.js')}}"></script>

 <!-- jQuery KenBurn Slider  -->
 <script type="text/javascript" src="{{url('public/bms/rs-plugin/js/jquery.themepunch.revolution.min.js')}}"></script>

<!-- Nicescroll  -->
<script src="{{url('public/bms/assets/js/jquery.nicescroll.min.js')}}"></script>

<!-- Javascript  -->
<script src="{{('public/bms/assets/js/js-payment.js')}}"></script>

	
    <!-- Custom Select -->
    <script type='text/javascript' src='{{ url("public/bms/assets/js/jquery.customSelect.js")}}'></script>
	
	<!-- Load Animo -->
	<script src="{{ url('public/bms/plugins/animo/animo.js')}}"></script>

    <!-- Picker -->	
	<script src="{{ url('public/bms/assets/js/jquery-ui.js')}}"></script>	


 <!-- CarouFredSel -->
 <script src="{{url('public/bms/assets/js/jquery.carouFredSel-6.2.1-packed.js')}}"></script>
 <script src="{{url('public/bms/assets/js/helper-plugins/jquery.touchSwipe.min.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/assets/js/helper-plugins/jquery.mousewheel.min.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/assets/js/helper-plugins/jquery.transit.min.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/assets/js/helper-plugins/jquery.ba-throttle-debounce.min.js')}}"></script>

 <!-- Custom Select -->
<script type='text/javascript' src="{{url('public/bms/assets/js/jquery.customSelect.js')}}"></script>


<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/jshashtable-2.1_src.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/jquery.numberformatter-1.2.3.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/tmpl.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/jquery.dependClass-0.1.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/draggable-0.1.js')}}"></script>
<script type="text/javascript" src="{{url('public/bms/plugins/jslider/js/jquery.slider.js')}}"></script>


 <script src="{{url('public/bms/dist/js/bootstrap.min.js')}}"></script>
</body>
</html>
