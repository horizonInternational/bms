
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Horizonwebhost">
    <meta name="keyword" content="suraj,lekhnath, holiday, horizon, web, host">
    <title>Horizonwebhost- @yield('title')</title>
    <link rel="icon" type="image/png" sizes="16x16"
          href="{{url('public/frontend/assets/images/favicon.ico')}}">

    <!-- Google Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Amaranth:400,700|Poppins:300,400,600,700" rel="stylesheet">

    <link href="{{ url('public/frontend/css/plugins.min.css') }}" rel="stylesheet">

    <link href="{{ url('public/frontend/css/font-awesome.min.css') }}" rel="stylesheet"/>
    <link rel="stylesheet" type="text/css" href=" {{ url('public/frontend/css/jquery-ui.css') }}" > -->



      <!-- Bootstrap -->
      <link href="{{url('public/bms/dist/css/bootstrap.css')}}" rel="stylesheet" media="screen">
      <link href="{{url('public/bms/assets/css/custom.css')}}" rel="stylesheet" media="screen">

      <!-- Carousel -->
  	<link href="{{url('public/bms/examples/carousel/carousel.css')}}" rel="stylesheet">


      <!-- Fonts -->
  	<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
  	<link href='http://fonts.googleapis.com/css?family=Open+Sans:700,400,300,300italic' rel='stylesheet' type='text/css'>
  	<!-- Font-Awesome -->
      <link rel="stylesheet" type="text/css" href="{{url('public/bms/assets/css/font-awesome.css')}}" media="screen" />
      <!--[if lt IE 7]><link rel="stylesheet" type="text/css" href="assets/css/font-awesome-ie7.css" media="screen" /><![endif]-->

      <!-- REVOLUTION BANNER CSS SETTINGS -->
      <link rel="stylesheet" type="text/css" href="{{url('public/bms/css/fullscreen.css')}}" media="screen" />
  	<link rel="stylesheet" type="text/css" href="{{url('public/bms/rs-plugin/css/settings.css')}}" media="screen" />

      <!-- Picker UI-->
  	<link rel="stylesheet" href="{{url('public/bms/assets/css/jquery-ui.css')}}" />

      <!-- jQuery -->
      <script src="{{url('public/bms/assets/js/jquery.v2.0.3.js')}}"></script>
      <link href="{{ url('public/bms/updates/update1/css/style01.css')}}" rel="stylesheet" media="screen">



      <!-- Bootstrap -->
<link href="{{url('public/bms/dist/css/bootstrap.css')}}" rel="stylesheet" media="screen">
<link href="{{url('public/bms/assets/css/custom.css')}}" rel="stylesheet" media="screen">

     <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>

  
<link rel="stylesheet" href="{{ url('public/bms/bus/css/style.css')}}">
      <!--bus-->
  
    <!-- Fonts -->  
  <link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:700,400,300,300italic' rel='stylesheet' type='text/css'> 



<link href="{{url('public/bms/examples/carousel/carousel.css')}}" rel="stylesheet">
<
<!-- Animo css-->
<link href="{{url('public/bms/plugins/animo/animate%2banimo.css')}}" rel="stylesheet" media="screen">

<!-- Picker -->
<link rel="stylesheet" href="{{url('public/bms/assets/css/jquery-ui.css')}}" />

<!-- jQuery -->
<script src="{{url('public/bms/assets/js/jquery.v2.0.3.js')}}"></script>
